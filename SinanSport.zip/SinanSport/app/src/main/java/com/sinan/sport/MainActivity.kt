package com.sinan.sport

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

// ---- Pre-roll ad settings: change these to your own advertiser ----
private const val AD_TITLE = "Your Ad Here"
private const val AD_TEXT = "Advertise with Sinan Sport. Tap to learn more."
private const val AD_LINK = "https://example.com"   // opens when the ad is tapped; "" = not clickable
private const val AD_SECONDS = 6                    // how long the ad shows; 0 = no ad
private const val AD_SKIP_AFTER = 3                 // Skip button appears after this many seconds

/**
 * Sinan Sport - a simple live sports player with exactly 6 channels.
 *
 * Tap a channel to watch it. Long-press a channel to set its name and stream link.
 */
class MainActivity : AppCompatActivity() {

    private val channelCount = 6

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var webView: WebView
    private lateinit var videoBox: FrameLayout
    private lateinit var adBox: FrameLayout
    private lateinit var adCountdown: TextView
    private lateinit var adSkip: Button
    private val handler = Handler(Looper.getMainLooper())
    private var adTask: Runnable? = null
    private var adSecondsLeft = 0
    private lateinit var header: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var status: TextView
    private val buttons = ArrayList<Button>()
    private var current = -1

    private val prefs by lazy { getSharedPreferences("sinan_sport", Context.MODE_PRIVATE) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun channelName(i: Int): String =
        prefs.getString("name_$i", null) ?: "Channel ${i + 1}"

    private fun channelUrl(i: Int): String =
        prefs.getString("url_$i", null) ?: "https://alwanlive.stream/?channel=${i + 1}&server=1"

    private fun isDirectStream(url: String): Boolean {
        val path = (Uri.parse(url).path ?: "").lowercase()
        return path.endsWith(".m3u8") || path.endsWith(".mpd") ||
            path.endsWith(".mp4") || path.endsWith(".ts")
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) {
                status.text = "Live: ${channelName(current)}"
            } else if (state == Player.STATE_BUFFERING) {
                status.text = "Buffering..."
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            status.text = "Can't play ${channelName(current)}. Check the link or your connection."
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B1220"))
        }

        // Header: app name + fullscreen button
        header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(8), dp(10))
        }
        val title = TextView(this).apply {
            text = "SINAN SPORT"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = 0.08f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val fullscreen = Button(this).apply {
            text = "Fullscreen"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
        }
        header.addView(title)
        header.addView(fullscreen)

        // Video
        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                // Keep the user on the channel's own site (blocks pop-up redirects).
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val host = request.url.host ?: return true
                    return !host.endsWith("alwanlive.stream")
                }
            }
        }
        videoBox = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                playerView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        // Pre-roll ad overlay (sits on top of the video until the ad ends)
        adCountdown = TextView(this).apply {
            setTextColor(Color.parseColor("#9AA7C0"))
            textSize = 12f
            setPadding(dp(12), dp(8), dp(12), 0)
        }
        adSkip = Button(this).apply {
            text = "Skip ad"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E11D48"))
            visibility = View.GONE
            setOnClickListener { endAd(current) }
        }
        val adCenter = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        adCenter.addView(TextView(this).apply {
            text = "SPONSORED"
            setTextColor(Color.parseColor("#9AA7C0"))
            textSize = 11f
            letterSpacing = 0.15f
            gravity = Gravity.CENTER
        })
        adCenter.addView(TextView(this).apply {
            text = AD_TITLE
            setTextColor(Color.WHITE)
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        })
        adCenter.addView(TextView(this).apply {
            text = AD_TEXT
            setTextColor(Color.parseColor("#D5DCEB"))
            textSize = 14f
            gravity = Gravity.CENTER
        })
        adBox = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#111827"))
            visibility = View.GONE
            isClickable = true
            if (AD_LINK.isNotBlank()) {
                setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AD_LINK)))
                }
            }
            addView(
                adCenter,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            addView(
                adCountdown,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.END
                )
            )
            addView(
                adSkip,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, dp(40),
                    Gravity.BOTTOM or Gravity.END
                ).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) }
            )
        }
        videoBox.addView(
            adBox,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // Status line
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#9AA7C0"))
            textSize = 13f
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        // Channel buttons: 3 rows x 2 columns
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        for (i in 0 until channelCount) {
            val b = Button(this).apply {
                isAllCaps = false
                textSize = 15f
                setTextColor(Color.WHITE)
                text = channelName(i)
                setOnClickListener { play(i) }
                setOnLongClickListener {
                    editChannel(i)
                    true
                }
            }
            buttons.add(b)
        }
        for (r in 0 until channelCount / 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val b = buttons[r * 2 + c]
                val lp = LinearLayout.LayoutParams(0, dp(56), 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                row.addView(b, lp)
            }
            panel.addView(row)
        }

        root.addView(header)
        root.addView(
            videoBox,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220))
        )
        root.addView(status)
        root.addView(panel)
        setContentView(root)

        applyLayout(resources.configuration)

        // First channel that already has a link; otherwise show a hint.
        current = (0 until channelCount).firstOrNull { channelUrl(it).isNotBlank() } ?: -1
        highlight()
        if (current == -1) {
            status.text = "Long-press a channel to add its name and stream link."
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val p = ExoPlayer.Builder(this).build()
        p.addListener(listener)
        playerView.player = p
        player = p
        webView.onResume()
        if (current >= 0) play(current)
    }

    override fun onStop() {
        super.onStop()
        cancelAd()
        webView.onPause()
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout(newConfig)
    }

    private fun applyLayout(config: Configuration) {
        val landscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (landscape) {
            header.visibility = View.GONE
            status.visibility = View.GONE
            panel.visibility = View.GONE
            videoBox.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            WindowCompat.setDecorFitsSystemWindows(window, false)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            header.visibility = View.VISIBLE
            status.visibility = View.VISIBLE
            panel.visibility = View.VISIBLE
            val width = resources.displayMetrics.widthPixels
            videoBox.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, width * 9 / 16
            )
            WindowCompat.setDecorFitsSystemWindows(window, true)
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun highlight() {
        buttons.forEachIndexed { i, b ->
            b.setBackgroundColor(
                Color.parseColor(if (i == current) "#E11D48" else "#1F2A44")
            )
        }
    }

    /** Tapping a channel: show the pre-roll ad first, then start the live stream. */
    private fun play(i: Int) {
        current = i
        highlight()
        cancelAd()
        if (channelUrl(i).isBlank() || AD_SECONDS <= 0) {
            startPlayback(i)
            return
        }
        player?.stop()
        webView.loadUrl("about:blank")
        adSecondsLeft = AD_SECONDS
        adSkip.visibility = View.GONE
        adBox.visibility = View.VISIBLE
        status.text = "Ad playing... ${channelName(i)} starts next."
        adTick(i)
    }

    private fun adTick(i: Int) {
        adCountdown.text = "Ad  $adSecondsLeft"
        if (AD_SECONDS - adSecondsLeft >= AD_SKIP_AFTER) {
            adSkip.visibility = View.VISIBLE
        }
        if (adSecondsLeft <= 0) {
            endAd(i)
            return
        }
        adSecondsLeft--
        val task = Runnable { adTick(i) }
        adTask = task
        handler.postDelayed(task, 1000)
    }

    private fun cancelAd() {
        adTask?.let { handler.removeCallbacks(it) }
        adTask = null
        adBox.visibility = View.GONE
    }

    private fun endAd(i: Int) {
        cancelAd()
        if (i >= 0) startPlayback(i)
    }

    private fun startPlayback(i: Int) {
        val url = channelUrl(i).trim()
        if (url.isEmpty()) {
            player?.stop()
            status.text = "${channelName(i)}: no stream link yet. Long-press the button to add one."
            return
        }
        if (!isDirectStream(url)) {
            // A web page (for example the channel's own site): show it in the in-app web player.
            player?.stop()
            playerView.visibility = View.GONE
            webView.visibility = View.VISIBLE
            webView.loadUrl(url)
            status.text = "Loading ${channelName(i)}..."
            return
        }
        webView.visibility = View.GONE
        webView.loadUrl("about:blank")
        playerView.visibility = View.VISIBLE
        val item = MediaItem.Builder().setUri(url).apply {
            if (url.contains(".m3u8", ignoreCase = true)) {
                setMimeType(MimeTypes.APPLICATION_M3U8)
            }
        }.build()
        player?.let {
            it.setMediaItem(item)
            it.prepare()
            it.playWhenReady = true
        }
        status.text = "Loading ${channelName(i)}..."
    }

    private fun editChannel(i: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val nameField = EditText(this).apply {
            hint = "Channel name"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(channelName(i))
        }
        val urlField = EditText(this).apply {
            hint = "Stream link (for example .m3u8)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(channelUrl(i))
        }
        box.addView(nameField)
        box.addView(urlField)

        AlertDialog.Builder(this)
            .setTitle("Channel ${i + 1}")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val newName = nameField.text.toString().trim().ifEmpty { "Channel ${i + 1}" }
                val newUrl = urlField.text.toString().trim()
                prefs.edit()
                    .putString("name_$i", newName)
                    .putString("url_$i", newUrl)
                    .apply()
                buttons[i].text = newName
                play(i)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
