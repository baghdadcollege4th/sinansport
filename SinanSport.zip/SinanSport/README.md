# Sinan Sport

A simple Android app for live sports streaming with exactly 6 channels.

- Tap a channel to watch it.
- Long-press a channel to set its name and stream link (HLS `.m3u8` works best). Saved on the phone.
- "Fullscreen" button, or just rotate the phone. Press Back to leave fullscreen.

Use only stream links you have the right to watch.

## Get the APK (no installs needed): GitHub

1. Create a free account at github.com and make a new repository.
2. Upload everything in this folder (keep the `.github` folder).
3. Open the **Actions** tab, choose **Build APK**, and wait about 3-5 minutes.
4. Open the finished run, download **SinanSport-apk**, unzip it, and install `app-debug.apk` on your phone
   (allow "Install unknown apps" when asked).

## Or build with Android Studio

Open this folder in Android Studio, let it sync, then Build > Build APK(s).
The file appears in `app/build/outputs/apk/debug/`.
